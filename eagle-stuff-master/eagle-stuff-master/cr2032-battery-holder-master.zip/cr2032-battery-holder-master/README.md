# cr2032-battery-holder
cr2032 battery holder library/footprint for use with Eagle (PCB design software).

PCB footprint for a 20mm CR2032 coin battery holder [like this one](http://www.jaycar.com.au/Power-Products-Electrical/Storage-Batteries/Holders,-Clips-%26-Snaps/20mm-Button-Cell-Battery-Holder/p/PH9238).

## To Use
Copy the .lib file into your Eagle library directory.
